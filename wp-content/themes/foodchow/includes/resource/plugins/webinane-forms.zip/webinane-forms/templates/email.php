
<div class="main-template">
	
	{{loop_start}}
	<strong>{{field_label}}</strong> : {{field_value}} <br>
	{{loop_end}}

	Regards,<br>
	<?php bloginfo('name'); ?><br>
</div>