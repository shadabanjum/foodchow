<?php

namespace App\Models;

use TypeRocket\Models\WPComment;

class Comment extends WPComment
{
}