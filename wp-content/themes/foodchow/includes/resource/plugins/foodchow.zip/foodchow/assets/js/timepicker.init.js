
jQuery(document).ready(function($){

	$('.tr-timepicker').timepicker();
});