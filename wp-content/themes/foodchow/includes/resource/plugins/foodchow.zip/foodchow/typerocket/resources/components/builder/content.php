<h1>Content Component</h1>
<?php
/** @var $form \TypeRocket\Elements\Form */
echo $form->text('Headline');
echo $form->editor('Content');